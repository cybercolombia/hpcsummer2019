#include <iostream>
#include <fstream>
#include <unistd.h>
#include <limits>
#include <cmath>
#include <sys/time.h>

#include "defs.h"
#define INFO_BUFFER_SIZE 1024

using namespace std;

int fib(int);
int fib_p(int,int);

int CUTOFF = 0;

int main(int argc, char *argv[]){
#ifdef _OPENMP
    printf("**MESSAGE** OpenMP enabled\n");
    (void) omp_set_dynamic(FALSE);
    if (omp_get_dynamic()) {printf("\t**Warning** dynamic adjustment of threads has been set\n");}
    (void) omp_set_num_threads(8);
    printf("Nested is %s\n",
        omp_get_nested() ? "supported" : "not supported"
    );
    (void) omp_set_nested(TRUE);
#else
    printf("**MESSAGE** OpenMP disabled\n");
#endif

    SimpleTimer_t t1;

    int N;
    int fibN = 0;
    printf("Enter a positive integer ");
    scanf("%d",&N);

    printf("\nPart 1\n");

    SimpleTimer_start( &t1 );
    printf(" fib[%d] = %d\n",N,fib(N));
    SimpleTimer_stop( &t1 );
    SimpleTimer_print( &t1 );

    printf("\nPart 2\n");

    for(CUTOFF == 0; CUTOFF < 20; CUTOFF++){
        SimpleTimer_start( &t1 );
        #pragma omp parallel shared(fibN)
        {
            #pragma omp single
            { fibN = fib_p(N,0); }
        }
        printf("CUTOFF = %d:: fib_p[%d] = %d\n",CUTOFF,N,fibN);
        SimpleTimer_stop( &t1 );
        SimpleTimer_print( &t1 );
    }

    return 0;
}


int fib(int x){
    if(x == 0 || x == 1)
        return 1;
    else
        return fib(x-1) + fib(x-2);
}

int fib_p(int x,int c){
    int a, b;
    if(c == CUTOFF)
        return fib(x);
    if(x == 0 || x == 1)
        return 1;
    else{
        #pragma omp task shared(a)
        a = fib_p(x-1,c+1);
        #pragma omp task shared(b)
        b = fib_p(x-2,c+1);
        #pragma omp taskwait
        return a+b;
    }
}
