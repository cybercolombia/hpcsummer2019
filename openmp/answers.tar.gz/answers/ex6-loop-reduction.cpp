#include <iostream>
#include <fstream>
#include <unistd.h>
#include <limits>
#include <cmath>
#include <sys/time.h>

#include "defs.h"
#define INFO_BUFFER_SIZE 1024

using namespace std;

int main(int argc, char *argv[]){
#ifdef _OPENMP
    printf("**MESSAGE** OpenMP enabled\n");
    (void) omp_set_dynamic(FALSE);
    if (omp_get_dynamic()) {printf("\t**Warning** dynamic adjustment of threads has been set\n");}
    (void) omp_set_num_threads(8);
#else
    printf("**MESSAGE** OpenMP disabled\n");
#endif

    SimpleTimer_t t1;

    int j,N = 200;
    Crandom r(10);
    double *v1;
    double norm_v1;
    CREATEARRAY(v1,double,N,r.gaussian(0,0.5));

    PRINTARRAY(v1,N);

    printf("\nPart 1\n");

    norm_v1 = 0;
    for(j = 0; j < N; j++)
        norm_v1 += v1[j]*v1[j];
    printf("v1 norm = %lf\n",norm_v1);

    printf("\nPart 2\n");

    norm_v1 = 0;
    #pragma omp parallel shared(j,N,norm_v1,v1)
    {
        #pragma omp for
        for(j = 0; j < N; j++)
            norm_v1 += v1[j]*v1[j];
    } /*-- End of parallel region --*/
    printf("v1 norm = %lf\n",norm_v1);

    printf("\nPart 3a\n");

    norm_v1 = 0;
    #pragma omp parallel shared(N,norm_v1,v1)
    {
        double tmp = 0;
        #pragma omp for
        for(j = 0; j < N; j++){
            tmp = v1[j]*v1[j];
            #pragma omp critical
            {
                norm_v1 += tmp;
            }
        }
    } /*-- End of parallel region --*/
    printf("v1 norm = %lf\n",norm_v1);

    printf("\nPart 3b\n");

    norm_v1 = 0;
    // #pragma omp parallel shared(N,norm_v1,v1)
    // {
    //     #pragma omp for
    //     for(j = 0; j < N; j++)
    //         #pragma omp critical
    //         {
    //             norm_v1 += v1[j]*v1[j];
    //         }
    // } /*-- End of parallel region --*/
    #pragma omp parallel for shared(N,norm_v1,v1)
    for(j = 0; j < N; j++)
        #pragma omp critical
        norm_v1 += v1[j]*v1[j];
    printf("v1 norm = %lf\n",norm_v1);

    printf("\nPart 4a\n");

    norm_v1 = 0;
    #pragma omp parallel shared(N,norm_v1,v1)
    {
        double tmp = 0;
        #pragma omp for
        for(j = 0; j < N; j++){
            tmp = v1[j]*v1[j];
            #pragma omp atomic
            norm_v1 += tmp;
        }
    } /*-- End of parallel region --*/
    printf("v1 norm = %lf\n",norm_v1);

    printf("\nPart 4b\n");

    norm_v1 = 0;
    #pragma omp parallel shared(N,norm_v1,v1)
    {
        #pragma omp for
        for(j = 0; j < N; j++)
            #pragma omp atomic
            norm_v1 += v1[j]*v1[j];
    } /*-- End of parallel region --*/
    printf("v1 norm = %lf\n",norm_v1);

    printf("\nPart 5\n");

    norm_v1 = 0;
    #pragma omp parallel shared(N,norm_v1,v1)
    {
        #pragma omp for reduction(+:norm_v1)
        for(j = 0; j < N; j++)
            norm_v1 += v1[j]*v1[j];
    } /*-- End of parallel region --*/
    printf("v1 norm = %lf\n",norm_v1);

    printf("\nPart 6\n");

    norm_v1 = 0;
    #pragma omp parallel for reduction(+:norm_v1)
    for(j = 0; j < N; j++)
        norm_v1 += v1[j]*v1[j];
    printf("v1 norm = %lf\n",norm_v1);

    printf("\nPart 7a\n");

    norm_v1 = 0;
    #pragma omp parallel shared(N,norm_v1,v1)
    {
        double tmp = 0;
        #pragma omp for ordered
        for(j = 0; j < N; j++){
            tmp = v1[j]*v1[j];
            #pragma omp ordered
            {
                norm_v1 += tmp;
            }
        }
    } /*-- End of parallel region --*/
    printf("v1 norm = %lf\n",norm_v1);

    printf("\nPart 7b\n");

    norm_v1 = 0;
    #pragma omp parallel for shared(N,norm_v1,v1) ordered
    for(j = 0; j < N; j++)
        #pragma omp ordered
        norm_v1 += v1[j]*v1[j];
    printf("v1 norm = %lf\n",norm_v1);

    return 0;
}
