/*************************************
Parallel version of traffic_ser.cpp
The size of the grid must be divisible
by the number of processes
**********************************/

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <mpi.h>
using namespace std;

#define ROADSIZE 1024000
#define ITERSIZE 10

double gettime(){
  return MPI_Wtime();
}

int init_road(int *road, int road_size, float density, uint seed){
  srand(seed);
  int ncar = 0;
  for(int i = 0; i < road_size; i++){
    float rnum = static_cast<float>(rand()) / RAND_MAX;
    if(rnum < density)
      road[i] = 1;
    else
      road[i] = 0;

    ncar += road[i];
  }
  return ncar;
}

int next(int i, int size){
  if(i == size-1)
    return 0;
  else
    return i+1;
}

int prev(int i, int size){
  if(i == 0)
    return size-1;
  else
    return i-1;
}

int update(int *old_road, int *road, int road_size){
  //update road
  int nmove = 0;
  for(int i = 1; i <= road_size; i++){
    int j = i-1; //PBC taken into account with sendrecv
    int k = i+1; //
    if(old_road[i] == 0){
      if(old_road[j] == 1){
	road[i] = 1;
      }else{
	road[i] = 0;
      }
    }else{
      if(old_road[k] == 1){
	road[i] = 1;
      }else{
	road[i] = 0;
	nmove++;
      }
    }
  }
  //backup road
  for(int i = 1; i <= road_size; i++)
    old_road[i] = road[i];
  return nmove;
}

int main(int argc, char* argv[]){
  int road_size = ROADSIZE; //size of the grid
  float density = 0.5; //target density
  uint seed = 3439;  //rng seed
  int iter = ITERSIZE;//No. of iterations
  int printfreq = (iter >= 10)? iter/10 : 1; //Printing frequency
  
  if(density > 1)
    density = 1;

  //initialize mpi environment and get rank/size-----------------
  MPI_Init(NULL, NULL);
  //Find out rank, size
  int rank, size;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  //-------------------------------------------------------------

  //Print initial parameters if rank is 0------------------------
  if(rank == 0){
    printf("Length of road is %d\n", road_size);
    printf("Number of iterations is %d \n", iter);
    printf("Target density of cars is %.3f \n", density);
    printf("Running on %d processes\n", size);
  }
  //-------------------------------------------------------------

  //Get local number of cells and allocate memmory---------------
  int local_size = road_size / size;
  int *old_road = new int[local_size+2];
  int *road = new int[local_size+2];
  //-------------------------------------------------------------
  
  
  //initialize road if rank is 0---------------------------------
  int ncars;
  int *big_road = NULL;
  if(rank == 0){
    big_road = new int[road_size];
    printf("Initialising road ...\n");
    ncars = init_road(big_road, road_size, density, seed);
    printf("...done\n");
    printf("Actual density of cars is %f\n\n", static_cast<float>(ncars) / road_size);

    printf("Scattering data...\n");
  }
  //------------------------------------------------------------

  // scatter data to all processes-------------------------------
  // Leave one space at the beginning and one at the end of old_road to
  // store the last element of previous process and the first element
  // of next process
  MPI_Scatter(big_road, local_size, MPI_INT, &old_road[1], local_size, MPI_INT, 0, MPI_COMM_WORLD);
  if(rank == 0){
    printf("...done\n");
    // //
    // printf("initial:\n");
    // for(int i = 0; i < road_size; i++)
    //   printf("%d ",big_road[i]);
    // printf("\n\n");
    // //
  }
  //------------------------------------------------------------

  // //
  // printf("rank %d: ",rank);
  // for(int i = 1; i < local_size+1; i++)
  //   printf("%d ",old_road[i]);
  // printf("\n");
  // //
  
  double tstart = gettime();
  
  for(int it = 0; it < iter; it++){
    int nextproc = next(rank, size);
    int prevproc = prev(rank, size);
    
    //send / recieve first and last elements----------------------
    MPI_Status status;
    MPI_Sendrecv(&old_road[local_size], 1, MPI_INT, nextproc, 1,
		 &old_road[0], 1, MPI_INT, prevproc, 1,
		 MPI_COMM_WORLD, &status);
    MPI_Sendrecv(&old_road[1], 1, MPI_INT, prevproc, 1,
		 &old_road[local_size+1], 1, MPI_INT, nextproc, 1,
		 MPI_COMM_WORLD, &status);
    //------------------------------------------------------------
    // //
    // printf("rank %d: ",rank);
    // for(int i = 0; i < local_size+2; i++)
    //   printf("%d ",old_road[i]);
    // printf("\n");
    // //

    //Update the road fragment
    int nmove = update(old_road, road, local_size);
    
    //Add nmove of each process to obtain the total--------------
    int tot_nmove;
    MPI_Allreduce(&nmove, &tot_nmove, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
    if(rank == 0 && it%printfreq == 0){
      printf("At iteration %d average velocity is %f \n",
	     it, static_cast<float>(tot_nmove) / ncars);
    }
    //-----------------------------------------------------------

    // //Gather the road segments to compare----------------
    // MPI_Gather(&old_road[1], local_size, MPI_INT, big_road, local_size, MPI_INT, 0, MPI_COMM_WORLD);
    // if(rank == 0){
    //   //
    //   for(int i = 0; i < road_size; i++)
    //     printf("%d ",big_road[i]);
    //   printf("\n\n");
    //   //
    // }
    // //---------------------------------------------------
  }

  double tstop = gettime();

  //Gather the road segments to compare-----------------
  MPI_Gather(&old_road[1], local_size, MPI_INT, big_road,
	     local_size, MPI_INT, 0, MPI_COMM_WORLD);
  //----------------------------------------------------
  
  //free the memory for the road
  delete[] road;
  delete[] old_road;

  if(rank == 0){
    // //
    // for(int i = 0; i < road_size; i++)
    //   printf("%d ",big_road[i]);
    // printf("\n");
    // //
    delete[] big_road;
    
    printf("\nFinished\n");
    printf("\nTime taken was  %f seconds\n", tstop-tstart);
    printf("Update rate was %f operations/s\n\n",
	   1.e-6*(static_cast<double>(road_size)*iter)/(tstop-tstart));
  }
  
  MPI_Finalize();
  
  return 0;
}
