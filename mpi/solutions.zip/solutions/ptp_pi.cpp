#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <mpi.h>

double pi_calc(int N, int start, int end){
  double pi4 = 0.;
  if(start < 1)
    printf("start must be > 0");
  else if(end > N)
    printf("end must be <= N");
  else{
    double val;
    for(int i = start; i <= end; i++){
      val = (double(i) - 0.5) / N;
      pi4 += 1. / (1+val*val);
    }
  }
  return 4*pi4 / N;
}

int main(){

  //initialize mpi environment ----------------------------------
  MPI_Init(NULL, NULL);
  
  int rank, size;
  MPI_Comm comm = MPI_COMM_WORLD; //Communicator
  //Find out rank, size
  MPI_Comm_rank(comm, &rank);
  MPI_Comm_size(comm, &size);
  //-------------------------------------------------------------

  //initial time
  double start_t = MPI_Wtime();
  
  int N = 840;
  //Each process takes a share of the work
  int res = N % size;
  int Nloc = (N-res) / size;
  if(rank == 0)
    Nloc += res;

  //Compute the pi part many times to ive enough workload
  double my_pi;
  for(int i = 0; i < 5000; i++)
    my_pi = pi_calc(N,rank*Nloc+1,(rank+1)*Nloc);
  printf("from %d: pi part = %f\n", rank, my_pi);

  if(rank > 0){
    MPI_Ssend(&my_pi, 1, MPI_DOUBLE, 0, 0, comm);
  }else{
    double* parts = new double[size];
    parts[0] = my_pi;
    for(int i = 1; i < size; i++){
      MPI_Recv(&parts[i], 1, MPI_DOUBLE, i, MPI_ANY_TAG, comm, MPI_STATUS_IGNORE);
    }
    
    double tot_pi = 0.;
    for(int i = 0; i < size; i++)
      tot_pi += parts[i];
    
    delete[] parts;
    printf("pi = %f\n", tot_pi);
  }  
  
  //final time
  double stop_t = MPI_Wtime();

  if(rank == 0){
    printf("\nTime taken was %f seconds \n", stop_t - start_t);
  }
  
  //Exit the mpi environment ------------------------------------
  MPI_Finalize();
  //-------------------------------------------------------------

  return 0;
}
