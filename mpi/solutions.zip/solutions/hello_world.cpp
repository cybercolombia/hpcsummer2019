#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <mpi.h>

int main(){

  //initialize mpi environment ----------------------------------
  MPI_Init(NULL, NULL);
  
  int rank, size;
  MPI_Comm comm = MPI_COMM_WORLD; //Communicator
  //Find out rank, size
  MPI_Comm_rank(comm, &rank);
  MPI_Comm_size(comm, &size);
  //-------------------------------------------------------------
  
  // Each process prints out its rank
  printf("Hello, world.  I am %d of %d\n", rank, size);

  //Exit the mpi environment ------------------------------------
  MPI_Finalize();
  //-------------------------------------------------------------

  return 0;
}
