#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <sys/time.h>
using namespace std;

#define ROADSIZE 1024000
#define ITERSIZE 10

double gettime(){
  struct timeval tp;
  gettimeofday (&tp, NULL);
  return tp.tv_sec + tp.tv_usec/(double)1.0e6;
}

int init_road(int *road, int road_size, float density, uint seed){
  srand(seed);
  int ncar = 0;
  for(int i = 0; i < road_size; i++){
    float rnum = static_cast<float>(rand()) / RAND_MAX;
    if(rnum < density)
      road[i] = 1;
    else
      road[i] = 0;
    
    ncar += road[i];
  }
  return ncar;
}

int next(int i, int size){
  if(i == size-1)
    return 0;
  else
    return i+1;
}

int prev(int i, int size){
  if(i == 0)
    return size-1;
  else
    return i-1;
}

int update(int *old_road, int *road, int road_size){
  //update road
  int nmove = 0;
  for(int i = 0; i < road_size; i++){
    int j = prev(i, road_size); //i-1 with PBC
    int k = next(i, road_size); //i+1 with PBC
    if(old_road[i] == 0){
      if(old_road[j] == 1){
	road[i] = 1;
      }else{
	road[i] = 0;
      }
    }else{
      if(old_road[k] == 1){
	road[i] = 1;
      }else{
	road[i] = 0;
	nmove++;
      }
    }
  }
  //backup road
  for(int i = 0; i < road_size; i++)
    old_road[i] = road[i];
  return nmove;
}

int main(int argc, char* argv[]){
  int road_size = ROADSIZE; //size of the grid
  float density = 0.5; //target density
  uint seed = 3439;  //rng seed
  int iter = ITERSIZE;//No. of iterations
  int printfreq = (iter >= 10)? iter/10 : 1; //Printing frequency
  
  if(density > 1)
    density = 1;

  printf("Length of road is %d\n", road_size);
  printf("Number of iterations is %d \n", iter);
  printf("Target density of cars is %.3f \n", density);
  
  //Allocate the road
  int *old_road = new int[road_size];
  int *road = new int[road_size];
  //initialize road
  printf("Initialising road ...\n");
  int ncars = init_road(old_road, road_size, density, seed);
  printf("...done\n");
  printf("Actual density of cars is %f\n\n", static_cast<float>(ncars) / road_size);

  // //
  // printf("initial:\n");
  // for(int i = 0; i < road_size; i++)
  //   printf("%d ",old_road[i]);
  // printf("\n\n");
  // //
  
  double tstart = gettime();
  
  for(int it = 0; it < iter; it++){
    int nmove = update(old_road, road, road_size);
    if(it%printfreq == 0){
      printf("At iteration %d average velocity is %f \n",
	     it, static_cast<float>(nmove) / ncars);
    }
    // //
    // for(int i = 0; i < road_size; i++)
    //   printf("%d ",road[i]);
    // printf("\n\n");
    // //
  }

  double tstop = gettime();

  // //
  // for(int i = 0; i < road_size; i++)
  //   printf("%d ",road[i]);
  // printf("\n");
  // //
  
  //free the memory for the road
  delete[] old_road;
  delete[] road;

  printf("\nFinished\n");
  printf("\nTime taken was  %f seconds\n", tstop-tstart);
  printf("Update rate was %f operations/s\n\n",
	 1.e-6*(static_cast<double>(road_size)*iter)/(tstop-tstart));
  
  return 0;
}
